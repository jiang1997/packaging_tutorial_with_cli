def cli():
    print("call by command example_cli")
